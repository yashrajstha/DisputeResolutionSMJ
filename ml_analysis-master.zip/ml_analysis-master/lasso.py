import csv
import math
import numpy as np

from sklearn import tree
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import KFold,StratifiedKFold
from imblearn.over_sampling import RandomOverSampler
from sklearn.preprocessing import scale, MinMaxScaler
from sklearn.linear_model import Lasso, SGDClassifier, LogisticRegression, ElasticNet, RidgeClassifier

from sklearn.svm import SVC, SVR, LinearSVC
from sklearn.tree import DecisionTreeClassifier, ExtraTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, BaggingClassifier, IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.covariance import EllipticEnvelope

from sklearn.metrics import f1_score, matthews_corrcoef
import matplotlib.pyplot as plt

from imblearn.over_sampling import SMOTE

def read_data(filename):
	with open(filename,'r') as f:
		reader = csv.reader(f)
		next(reader)
		data = []
		labels = []
		for row in reader:
			d = []
			# d = [float(row[i]) for i in range(1,1+nfeatures)]
			nfeatures = len(row)-2
			for i in range (1, 1+nfeatures):
				if isfloat(row[i]):
					d.append(float(row[i]))
				else:
					d.append(float(0))
			data.append(d)

			if row[len(row)-1] == "1":
				labels.append(1)
			else:
				labels.append(0)

		return np.array(data), np.array(labels)

def isfloat(value):
	try:
		float(value)
		return True
	except ValueError:
		return False

def data_clean(data, labels):
	clf = SVC(C=12, kernel="rbf", gamma='scale')
	clf = clf.fit(data, labels)
	pred = clf.predict(data)
	idx=[]
	for i in range(len(data)):
		if pred[i]==labels[i]:
			idx.append(i)
	return data[idx], labels[idx]

def confusion(pred,labels):
	TP = 0
	TN = 0
	FP = 0
	FN = 0
	total = len(labels)
	for i in range(total):
		if pred[i] == labels[i]:
			if pred[i]==1:
				TP += 1
			else:
				TN += 1
		else:
			if pred[i]==1:
				FP += 1
			else:
				FN += 1
	return TP, TN, FP, FN

def acc_f1(clf, kf, nfeatures, data, labels):
	lasso_scores = []
	f1_scores = []
	mcc_scores = []
	#nfeatures = 11	
	tps = []
	tns = []
	fps = []
	fns = []
	p_scores = []
	n_scores = []
	rank_per_case = np.zeros((nfeatures))
  
	for train_idx, test_idx in kf.split(data,labels):
		train_data = data[train_idx]
		test_data = data[test_idx]
		train_labels = labels[train_idx]
		test_labels = labels[test_idx]

		clf = clf.fit(train_data,train_labels)

		lasso_score = clf.score(test_data,test_labels)
		lasso_scores.append(lasso_score)

		lasso_pred = clf.predict(test_data)
		
		
		f1 = f1_score(test_labels, lasso_pred)
		mcc = matthews_corrcoef(test_labels, lasso_pred)
		f1_scores.append(f1)
		mcc_scores.append(mcc)

		coef_per_fold = clf.coef_
		coef_rank = np.argsort(np.abs(coef_per_fold)).flatten()
		rank_per_fold = np.zeros(nfeatures)
		for i in range(nfeatures):
			rank_per_fold[coef_rank[i]] = i
		rank_per_case = np.add(rank_per_case,rank_per_fold)
		
		tp, tn, fp, fn = confusion(lasso_pred,test_labels)
		tps.append(tp)
		tns.append(tn)
		fps.append(fp)
		fns.append(fn)
		p_scores.append(1.0*tp/(tp+fn))
		n_scores.append(1.0*tn/(tn+fp))
		
	return lasso_scores, f1_scores, mcc_scores, rank_per_case, tps, tns, fps, fns, p_scores, n_scores

def figure_plot(title, x, y_list, x_label, y_label, color_list, filename=None):
	plt.figure()
	for i in range(len(y_list)):
		plt.plot(x, y_list[i], color=color_list[i], linestyle="-", linewidth=1)
	plt.xlabel(x_label)
	plt.ylabel(y_label)
	plt.title(title)
	if filename != None:
		plt.savefig(filename)
	plt.show()

def run(Classifier, para_name, para_list, kwargs, nfeatures, kf, data, labels):
	
	print(data.shape, labels.shape)
	result = []
	f1_result = []
	mcc_result = []
	
	tps_list = []
	tns_list = []
	fps_list = []
	fns_list = []
	rank = np.zeros((nfeatures))
	for para in para_list:

		para_dict = {para_name: para}
		clf = Classifier(**para_dict, **kwargs)
		#print(clf)
		lasso_scores, f1_scores, mcc_scores, rank_per_case, tps, tns, fps, fns, p_scores, n_scores = acc_f1(clf, kf, nfeatures, data, labels)
		
		result.append(np.mean(lasso_scores))
		f1_result.append(np.mean(f1_scores))
		mcc_result.append(np.mean(mcc_scores))
		
		tps_list.append(tps)
		tns_list.append(tns)
		fps_list.append(fps)
		fns_list.append(fns)
		
		rank = np.add(rank,rank_per_case)
	
	return result, f1_result,  mcc_result, rank, tps_list, tns_list, fps_list, fns_list, p_scores, n_scores

def top_features(feature_names, n, rank):

	rank_val_order = np.argsort(rank).flatten()
	top = []
	for i in range(len(rank)-1,len(rank)-1-n,-1):
		top.append(feature_names[rank_val_order[i]])
		print(feature_names[rank_val_order[i]],)
	return top

def print_table(result, f1_result, mcc_result, rank, tps_list, tns_list, fps_list, fns_list, p_scores, n_scores):
	print("feature rank mean: ", rank)
	print("accuracy mean: ", np.mean(result), "f1_score mean: ", np.mean(f1_result), "mcc_score mean: ", np.mean(mcc_result))
	print("tp", np.sum(np.mean(tps_list, axis=0)),"tn", np.sum(np.mean(tns_list, axis=0)),"fp", np.sum(np.mean(fps_list, axis=0)),"fn", np.sum(np.mean(fns_list, axis=0)))
	print("p_score mean: ", np.mean(p_scores), "n_score mean: ", np.mean(n_scores))

def extract_data_new_labels(datafile, labelfile):
	label_file = open(labelfile,'r')
	label_reader = csv.reader(label_file)
	next(label_reader)
	label_dict = {}
	for row in label_reader:
		label_dict[row[0]] = int(row[-1])
	label_file.close()
	
	with open(datafile,'r') as f:
		reader = csv.reader(f)
		next(reader)
		data = []
		labels = []
		for row in reader:
			d = []
			# d = [float(row[i]) for i in range(1,1+nfeatures)]
			nfeatures = len(row)-2
			for i in range (1, 1+nfeatures):
				if isfloat(row[i]):
					d.append(float(row[i]))
				else:
					d.append(float(0))
			data.append(d)
			labels.append(label_dict[row[0]])
			
		return np.array(data), np.array(labels)
		
def data_transform_mul_brownfield(data, nfeatures, feature_names):
	idx_p_brownfeild = data[:, 5]==1
	idx_n_brownfeild = data[:, 5]==0	
	print(np.count_nonzero(idx_p_brownfeild==True), np.count_nonzero(idx_n_brownfeild==True))
	musk = np.array(feature_names)!="brownfield"
	print(musk)
	data = data[:, musk]	
	data = np.concatenate((data, data), axis=1)
	data[idx_n_brownfeild, (nfeatures - 1):] = 0
	
	nfeatures = (nfeatures - 1) * 2
	feature_names = np.array(feature_names)[musk]
	feature_names = np.append(feature_names, feature_names)
	
	return data, nfeatures, feature_names

def data_transform_brownfield(data, labels, nfeatures, feature_names, brownfield):
	idx_p_brownfeild = data[:, 5]==1
	idx_n_brownfeild = data[:, 5]==0	
	print(np.count_nonzero(idx_p_brownfeild==True), np.count_nonzero(idx_n_brownfeild==True))
	musk = np.array(feature_names)!="brownfield"
	print(musk)
	
	if brownfield == 0:
		data = data[np.ix_(idx_n_brownfeild, musk)]
		labels = labels[idx_n_brownfeild]
	else:
		data = data[np.ix_(idx_p_brownfeild, musk)]
		labels = labels[idx_p_brownfeild]
	
	feature_names = np.array(feature_names)[musk]
	nfeatures = nfeatures - 1
	
	return data, labels, nfeatures, feature_names

if __name__ == "__main__":
	nfold = 8
	nfeatures = 11
	feature_names = ["Info", "Procedure", "uniqueparticipants", "AdminSize", "polarization_total", "brownfield","project_size_person", "gini_freq", "project_age", "ifstart","ratio"]

	data, labels = read_data('data_new_183.csv')
	#data, labels = extract_data_new_labels('data_new_183.csv', 'merge_final.csv')
	#data, nfeatures, feature_names = data_transform_mul_brownfield(data, nfeatures, feature_names)
	#data, labels, nfeatures, feature_names = data_transform_brownfield(data, labels, nfeatures, feature_names, 0)
	#data, labels, nfeatures, feature_names = data_transform_brownfield(data, labels, nfeatures, feature_names, 1)
	data = scale(data)
	
	#data, labels = data_clean(data, labels)
	npos = np.count_nonzero(labels)
	nneg = len(labels)-npos
	print("pos", npos, "neg", nneg)

	# cross-validation
	kf = StratifiedKFold(n_splits=nfold, shuffle=True)
	
	# brownfield == 0 or 1
	#data = data[np.ix_(idx_n_brownfeild, musk)]
	#labels = labels[idx_n_brownfeild]

	# SMOTE analysis
	#SM = SMOTE(random_state=42)
	#data, labels = SM.fit_resample(data, labels)
	#print(data.shape)
	
	"--------------------------------------"
	"--------------------------------------"
	"Logistic Regression with L1 penalty"
	"--------------------------------------"
	"--------------------------------------"
	#C = [0.01, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100]
	C = [1]
	kwargs = {'penalty': "l1", 'solver': "liblinear"}
	para_name = "C"
	para_list = C
	result, f1_result, mcc_result, rank, tps_list, tns_list, fps_list, fns_list, p_scores, n_scores = \
		run(LogisticRegression, para_name, para_list, kwargs, nfeatures, kf, data, labels)
	print_table(result, f1_result, mcc_result, rank/(nfold*len(para_list)), tps_list, tns_list, fps_list, fns_list, p_scores, n_scores)
	
	print("top three features from Logistic Regression")		
	top = top_features(feature_names, 3, rank)
	print("\n")
	
	"record result for 50 runs"
	#figure_plot(title="accuracy(red) and f1-score(green) for 50 runs \n accuracy mean:%f, median:%f, std:%f \n f1-score mean:%f, median:%f, std:%f" \
	#		% (np.mean(result), np.median(result), np.std(result), np.mean(f1_result), np.median(f1_result), np.std(f1_result)), \
	#		x=[i for i in range(len(C))], y_list=[result, f1_result], x_label="n", y_label="score", color_list=["r", "g"], filename=None)
	"record result for different C"
	#figure_plot(title="Logistic Regression with L1 penalty" + "\n" + "top three features: " + top[0] + ", " + top[1] + ", " + top[2], \
	#		x=list(map(math.log, C)), y_list=[result, f1_result], x_label="log(c)", y_label="score", color_list=["r", "g"], filename=None)



	"--------------------------------------"
	"--------------------------------------"
	"-------------ElasticNet---------------"
	"--------------------------------------"
	"--------------------------------------"
	#l1_ratios = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
	l1_ratios = [0.5]
	kwargs = {"loss": "log", "penalty": "elasticnet", "class_weight": None, "tol": 1e-3, "alpha": 0.0001}
	para_name = "l1_ratio"
	para_list = l1_ratios
	
	result, f1_result, mcc_result, rank, tps_list, tns_list, fps_list, fns_list, p_scores, n_scores = \
		run(SGDClassifier, para_name, para_list, kwargs, nfeatures, kf, data, labels)
	print_table(result, f1_result, mcc_result, rank/(nfold*len(para_list)), tps_list, tns_list, fps_list, fns_list, p_scores, n_scores)
	
	print("top three features from ElasticNet")		
	top = top_features(feature_names, 3, rank)
	print("\n")

	"record result for 50 runs"
	#figure_plot(title="accuracy(red) and f1-score(green) for 50 runs \n accuracy mean:%f, median:%f, std:%f \n f1-score mean:%f, median:%f, std:%f" \
	#		% (np.mean(result), np.median(result), np.std(result), np.mean(f1_result), np.median(f1_result), np.std(f1_result)), \
	#		x=[i for i in range(len(l1_ratios))], y_list=[result, f1_result], x_label="n", y_label="score", color_list=["r", "g"], filename=None)
	"record result for different C"
	#figure_plot(title="ElasticNet" + "\n" + "top three features: " + top[0] + ", " + top[1] + ", " + top[2], \
	#		x=l1_ratios, y_list=[result, f1_result], x_label="l1_ratios", y_label="score", color_list=["r", "g"], filename=None)
	
	
	
	"--------------------------------------"
	"--------------------------------------"
	"-----------RidgeClassifier------------"
	"--------------------------------------"
	"--------------------------------------"
	#alphas = [0.01, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100]
	alphas = [0.1]
	kwargs = {"tol": 0.001, "solver": "auto"}
	para_name = "alpha"
	para_list = alphas
	
	result, f1_result, mcc_result, rank, tps_list, tns_list, fps_list, fns_list, p_scores, n_scores = \
		run(RidgeClassifier, para_name, para_list, kwargs, nfeatures, kf, data, labels)
	print_table(result, f1_result, mcc_result, rank/(nfold*len(para_list)), tps_list, tns_list, fps_list, fns_list, p_scores, n_scores)
	
	print("top three features from RidgeClassifier")
	top = top_features(feature_names, 3, rank)
	
	"record result for 50 runs"
	#figure_plot(title="accuracy(red) and f1-score(green) for 50 runs \n accuracy mean:%f, median:%f, std:%f \n f1-score mean:%f, median:%f, std:%f" \
	#		% (np.mean(result), np.median(result), np.std(result), np.mean(f1_result), np.median(f1_result), np.std(f1_result)), \
	#		x=[i for i in range(len(alphas))], y_list=[result, f1_result], x_label="n", y_label="score", color_list=["r", "g"], filename=None)
	"record result for different C"
	#figure_plot(title="RidgeClassifier" + "\n" + "top three features: " + top[0] + ", " + top[1] + ", " + top[2], \
	#		x=list(map(math.log, alphas)), y_list=[result, f1_result], x_label="log(alphas)", y_label="score", color_list=["r", "g"], filename=None)
