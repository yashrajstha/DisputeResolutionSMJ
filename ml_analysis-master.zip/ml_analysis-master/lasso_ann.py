import csv
import math
import numpy as np
from sklearn import tree
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import BaggingClassifier, VotingClassifier, RandomForestClassifier, IsolationForest
from sklearn.model_selection import KFold,StratifiedKFold
from imblearn.over_sampling import RandomOverSampler
from sklearn.preprocessing import scale, MinMaxScaler

from sklearn.linear_model import SGDClassifier, LogisticRegression
from sklearn.svm import SVC, LinearSVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import LocalOutlierFactor

from sklearn.metrics import f1_score, matthews_corrcoef
import matplotlib.pyplot as plt

from imblearn.over_sampling import SMOTE

def error_rate(votes,labels):
	hit = 0
	for i in range(len(votes)):
		if votes[i] == labels[i]:
			hit = hit+1;
	return 1.0*hit/len(votes)
"""
def generate_data(s,max_val,min_val):
	data = []
	print("generating",s,"data")
	for i in range(s):
		d = []
		for j in range(len(max_val)):
			r = (max_val[j]-min_val[j])*np.random.random_sample()+min_val[j]
			d.append(r)
		data.append(d)
	return np.array(data)
"""
def isfloat(value):
	try:
		float(value)
		return True
	except ValueError:
		return False

def read_data(filename):
	with open(filename,'r') as f:
		reader = csv.reader(f)
		next(reader)
		data = []
		labels = []
		for row in reader:
			d = []
			# d = [float(row[i]) for i in range(1,1+nfeatures)]
			nfeatures = len(row)-2
			for i in range (1, 1+nfeatures):
				if isfloat(row[i]):
					d.append(float(row[i]))
				else:
					d.append(float(0))
			data.append(d)

			if row[len(row)-1] == "1":
				labels.append(1)
			else:
				labels.append(0)

		return np.array(data), np.array(labels)

def data_clean(data, labels):
	clf = SVC(C=12, kernel="rbf", gamma='scale')
	clf = clf.fit(data, labels)
	pred = clf.predict(data)
	idx=[]
	for i in range(len(data)):
		if pred[i]==labels[i]:
			idx.append(i)
	return data[idx], labels[idx]

def confusion(pred,labels):
	TP = 0
	TN = 0
	FP = 0
	FN = 0
	total = len(labels)
	for i in range(total):
		if pred[i] == labels[i]:
			if pred[i]==1:
				TP += 1
			else:
				TN += 1
		else:
			if pred[i]==1:
				FP += 1
			else:
				FN += 1
	return TP, TN, FP, FN

def acc_f1(nnclf, clf, nbag, kf, nfeatures, data, labels):
	
	nn_scores = []
	nn_f1_scores = []
	nn_mcc_scores = []
	tree_scores = []
	tree_f1_scores = []
	tree_mcc_scores = []
	
	#nfeatures = 11	
	rank = np.zeros((nfeatures))
	
	tps = []
	tns = []
	fps = []
	fns = []
	p_scores = []
	n_scores = []
	
	for train_idx, test_idx in kf.split(data,labels):
		train_data = data[train_idx]
		test_data = data[test_idx]
		train_labels = labels[train_idx]
		test_labels = labels[test_idx]
		
		rank_per_fold = np.zeros((nfeatures))	
		
		#nnclf = MLPClassifier(hidden_layer_sizes=(2, 2), activation='relu', solver='lbfgs', max_iter=1000, tol=0.0001, warm_start=False)
		
		bagging = BaggingClassifier(nnclf, n_estimators=nbag, oob_score = False)		
		bagging.fit(train_data,train_labels)		
		nn_scores.append(bagging.score(test_data,test_labels))
		pred = np.array(bagging.predict(test_data))
		nn_f1_scores.append(f1_score(test_labels, pred))
		nn_mcc_scores.append(matthews_corrcoef(test_labels, pred))
		
		random_data = np.random.randn(3*len(train_labels), nfeatures)
		new_data = np.copy(train_data)
		new_data = np.append(new_data,random_data,axis=0)
		
		new_labels = bagging.predict(new_data)
		new_labels = np.array(new_labels)
		
		#clf = LogisticRegression(penalty="l1", C=1, solver="liblinear")
		clf = clf.fit(new_data,new_labels)
		
		tree_scores.append(clf.score(test_data,test_labels))
		tree_f1_scores.append(f1_score(test_labels, clf.predict(test_data)))
		tree_mcc_scores.append(matthews_corrcoef(test_labels, clf.predict(test_data)))
	
		coef_per_fold = clf.coef_
		coef_rank = np.argsort(np.abs(coef_per_fold)).flatten()
		rank_per_fold = np.zeros(nfeatures)
		for i in range(nfeatures):
			rank_per_fold[coef_rank[i]] = i
		rank = np.add(rank,rank_per_fold)
		
		tp, tn, fp, fn = confusion(clf.predict(test_data),test_labels)
		tps.append(tp)
		tns.append(tn)
		fps.append(fp)
		fns.append(fn)
		p_scores.append(1.0*tp/(tp+fn))
		n_scores.append(1.0*tn/(tn+fp))
		
	return nn_scores, nn_f1_scores, nn_mcc_scores, tree_scores, tree_f1_scores, tree_mcc_scores, rank, tps, tns, fps, fns, p_scores, n_scores

def figure_plot(title, x, y_list, x_label, y_label, color_list, filename=None):
	plt.figure()
	for i in range(len(y_list)):
		plt.plot(x, y_list[i], color=color_list[i], linestyle="-", linewidth=1)
	plt.xlabel(x_label)
	plt.ylabel(y_label)
	plt.title(title)
	if filename != None:
		plt.savefig(filename)
	plt.show()

def run(Classifier, para_name_nn, para_list_nn, para_name_clf, para_list_clf, kwargs_nn, kwargs_clf, nfeatures, n_bags, kf, data, labels):

	print(data.shape, labels.shape)
	nn_result = []
	nn_f1_result = []
	nn_mcc_result = []
	tree_result = []
	tree_f1_result = []
	tree_mcc_result = []
	
	tps_list = []
	tns_list = []
	fps_list = []
	fns_list = []
	rank = np.zeros((nfeatures))
	
	"only one of (n_bags, para_list_nn, para_list_clf) has len > 1"
	for n_bag in n_bags:
		for para_nn in para_list_nn:
			for para_clf in para_list_clf:
				
				para_dict_nn = {para_name_nn: para_nn}
				para_dict_clf = {para_name_clf: para_clf}
				nnclf = MLPClassifier(**para_dict_nn, **kwargs_nn)
				clf = Classifier(**para_dict_clf, **kwargs_clf)
				
				nn_scores, nn_f1_scores, nn_mcc_scores, tree_scores, tree_f1_scores, tree_mcc_scores, rank_per_case, tps, tns, fps, fns, p_scores, n_scores = \
					acc_f1(nnclf, clf, n_bag, kf, nfeatures, data, labels)
		
				nn_result.append(np.mean(nn_scores))
				nn_f1_result.append(np.mean(nn_f1_scores))
				nn_mcc_result.append(np.mean(nn_mcc_scores))
				tree_result.append(np.mean(tree_scores))
				tree_f1_result.append(np.mean(tree_f1_scores))
				tree_mcc_result.append(np.mean(tree_mcc_scores))
				tps_list.append(tps)
				tns_list.append(tns)
				fps_list.append(fps)
				fns_list.append(fns)

				rank = np.add(rank,rank_per_case)
	
	return nn_result, nn_f1_result, nn_mcc_result, tree_result, tree_f1_result, tree_mcc_result, rank, tps_list, tns_list, fps_list, fns_list, p_scores, n_scores

def top_features(feature_names, n, rank):

	rank_val_order = np.argsort(rank).flatten()
	top = []
	for i in range(len(rank)-1,len(rank)-1-n,-1):
		top.append(feature_names[rank_val_order[i]])
		print(feature_names[rank_val_order[i]],)
	return top

def print_table(nn_result, nn_f1_result, nn_mcc_result, tree_result, tree_f1_result, tree_mcc_result, rank, tps_list, tns_list, fps_list, fns_list, p_scores, n_scores):
	print("feature rank mean: ", rank)
	print("accuracy ANN mean: ", np.mean(nn_result), "f1_score  ANN mean: ", np.mean(nn_f1_result), "MCC ANN mean: ", np.mean(nn_mcc_result))
	print("accuracy LASSO_ANN mean: ", np.mean(tree_result), "f1_score  LASSO_ANN mean: ", np.mean(tree_f1_result), "MCC LASSO_ANN mean: ", np.mean(tree_mcc_result))
	print("tp", np.sum(np.mean(tps_list, axis=0)),"tn", np.sum(np.mean(tns_list, axis=0)),"fp", np.sum(np.mean(fps_list, axis=0)),"fn", np.sum(np.mean(fns_list, axis=0)))
	print("p_score mean: ", np.mean(p_scores), "n_score mean: ", np.mean(n_scores))

def extract_data_new_labels(datafile, labelfile):
	label_file = open(labelfile,'r')
	label_reader = csv.reader(label_file)
	next(label_reader)
	label_dict = {}
	for row in label_reader:
		label_dict[row[0]] = int(row[-1])
	label_file.close()
	
	with open(datafile,'r') as f:
		reader = csv.reader(f)
		next(reader)
		data = []
		labels = []
		for row in reader:
			d = []
			# d = [float(row[i]) for i in range(1,1+nfeatures)]
			nfeatures = len(row)-2
			for i in range (1, 1+nfeatures):
				if isfloat(row[i]):
					d.append(float(row[i]))
				else:
					d.append(float(0))
			data.append(d)
			labels.append(label_dict[row[0]])
			
		return np.array(data), np.array(labels)

def data_transform_mul_brownfield(data, nfeatures, feature_names):
	idx_p_brownfeild = data[:, 5]==1
	idx_n_brownfeild = data[:, 5]==0	
	print(np.count_nonzero(idx_p_brownfeild==True), np.count_nonzero(idx_n_brownfeild==True))
	musk = np.array(feature_names)!="brownfield"
	print(musk)
	data = data[:, musk]	
	data = np.concatenate((data, data), axis=1)
	data[idx_n_brownfeild, (nfeatures - 1):] = 0
	
	nfeatures = (nfeatures - 1) * 2
	feature_names = np.array(feature_names)[musk]
	feature_names = np.append(feature_names, feature_names)
	
	return data, nfeatures, feature_names
	
def data_transform_brownfield(data, labels, nfeatures, feature_names, brownfield):
	idx_p_brownfeild = data[:, 5]==1
	idx_n_brownfeild = data[:, 5]==0	
	print(np.count_nonzero(idx_p_brownfeild==True), np.count_nonzero(idx_n_brownfeild==True))
	musk = np.array(feature_names)!="brownfield"
	print(musk)
	
	if brownfield == 0:
		data = data[np.ix_(idx_n_brownfeild, musk)]
		labels = labels[idx_n_brownfeild]
	else:
		data = data[np.ix_(idx_p_brownfeild, musk)]
		labels = labels[idx_p_brownfeild]
	
	feature_names = np.array(feature_names)[musk]
	nfeatures = nfeatures - 1
	
	return data, labels, nfeatures, feature_names
	
if __name__ == "__main__":

	nfold = 8
	nfeatures = 11
	feature_names = ["Info", "Procedure", "uniqueparticipants", "AdminSize", "polarization_total", "brownfield","project_size_person", "gini_freq", "project_age", "ifstart","ratio"]
	
	data, labels = read_data('data_new_183.csv')
	#data, labels = extract_data_new_labels('data_new_183.csv', 'merge_final.csv')
	#data, nfeatures, feature_names = data_transform_mul_brownfield(data, nfeatures, feature_names)
	#data, labels, nfeatures, feature_names = data_transform_brownfield(data, labels, nfeatures, feature_names, 0)
	#data, labels, nfeatures, feature_names = data_transform_brownfield(data, labels, nfeatures, feature_names, 1)
	
	data = scale(data)	
	#data, labels = data_clean(data, labels)
	
	npos = np.count_nonzero(labels)
	nneg = len(labels)-npos
	print("pos", npos, "neg", nneg)

	# cross-validation
	kf = StratifiedKFold(n_splits=nfold, shuffle=True)
	
	#data = data[np.ix_(idx_n_brownfeild, musk)]
	#labels = labels[idx_n_brownfeild]
	
	SM = SMOTE(random_state=42)
	data, labels = SM.fit_resample(data, labels)
	print(data.shape)

		
	activations = ["identity", "logistic", "tanh", "relu"]
	hidden_units = [1, 2, 4, 8, 10]
	alphas = [1e-6, 1e-5, 1e-4, 1e-3, 1e-2]
	#n_bags = [2, 4, 8, 16, 32]
	n_bags = [16]
		
	"number of bags"
	n_bags = [16]
	para_name_nn = "hidden_layer_sizes"
	para_list_nn = [(2,)]
	para_name_clf = "C"
	para_list_clf = [1]
	
	kwargs_nn = {"activation": 'relu', "solver": 'lbfgs', "max_iter": 1000, "tol": 0.0001, "warm_start": False}
	kwargs_clf = {"penalty": "l1", "solver": "liblinear"}

	nn_result, nn_f1_result, nn_mcc_result, tree_result, tree_f1_result, tree_mcc_result, rank, tps_list, tns_list, fps_list, fns_list, p_scores, n_scores = \
		run(LogisticRegression, para_name_nn, para_list_nn, para_name_clf, para_list_clf, kwargs_nn, kwargs_clf, nfeatures, \
			n_bags, kf, data, labels)
	
	print_table(nn_result, nn_f1_result, nn_mcc_result, tree_result, tree_f1_result, tree_mcc_result, \
		rank/(nfold*len(para_list_nn)*len(para_list_clf)*len(n_bags)), tps_list, tns_list, fps_list, fns_list, p_scores, n_scores)
	print("top three features")
	top = top_features(feature_names, 3, rank)
	print("\n")

		
		
	#plt.figure()
	#plt.plot([i for i in range(len(n_bags))], nn_result, color="r", linestyle="-", linewidth=1)
	#plt.plot([i for i in range(len(n_bags))], nn_f1_result, color="g", linestyle="-", linewidth=1)
	#plt.xlabel("n")
	#plt.title("accuracy(red) and f1-score(green) for 50 runs of ANN \n accuracy mean:%f, median:%f, std:%f \n f1-score mean:%f, median:%f, std:%f" \
	#		% (np.mean(nn_result), np.median(nn_result), np.std(nn_result), np.mean(nn_f1_result), np.median(nn_f1_result), np.std(nn_f1_result)))
	#plt.savefig("Lasso_ann_nn_result.png")
		
	#plt.figure()
	#plt.plot([i for i in range(len(n_bags))], tree_result, color="r", linestyle="-", linewidth=1)
	#plt.plot([i for i in range(len(n_bags))], tree_f1_result, color="g", linestyle="-", linewidth=1)
	#plt.xlabel("n")
	#plt.title("accuracy(red) and f1-score(green) for 50 runs of ANN+Lasso \n accuracy mean:%f, median:%f, std:%f \n f1-score mean:%f, median:%f, std:%f" \
	#		% (np.mean(tree_result), np.median(tree_result), np.std(tree_result), np.mean(tree_f1_result), np.median(tree_f1_result), np.std(tree_f1_result)))
	#plt.savefig("Lasso_ann_nn_plus_lasso_result.png")
		
	#plt.show()

	#plt.figure()
	#plt.plot(list(map(math.log, n_bags)), nn_result, color="r", linestyle="-", linewidth=1)
	#plt.plot(list(map(math.log, n_bags)), tree_result, color="g", linestyle="-", linewidth=1)
	#plt.xlabel("log(n_bags)")
	#plt.ylabel("accuracy")
	#plt.title("lasso + ann with different number of bags (red for nn, green for lassoann)" + "\n" + "top three features: " + top[0] + ", " + top[1] + ", " + top[2])
	#plt.savefig("LASSO_ann_n_bag_accuarcy.png")
		
	#plt.figure()
	#plt.plot(list(map(math.log, n_bags)), nn_f1_result, color="r", linestyle="-", linewidth=1)
	#plt.plot(list(map(math.log, n_bags)), tree_f1_result, color="g", linestyle="-", linewidth=1)
	#plt.xlabel("log(n_bags)")
	#plt.ylabel("f1_score")
	#plt.title("lasso + ann with different number of bags (red for nn, green for lassoann)" + "\n" + "top three features: " + top[0] + ", " + top[1] + ", " + top[2])
	#plt.savefig("LASSO_ann_n_bag_f1_score.png")
	#plt.show()
		
	"""
	"hidden units"
	rank = np.zeros((nfeatures))
	nn_result = []
	nn_f1_result = []
	tree_result = []
	tree_f1_result = []		
	for n_units in hidden_units:
		nnclf = MLPClassifier(hidden_layer_sizes=(n_units,), activation='relu', solver='lbfgs', max_iter=1000, tol=0.0001, warm_start=False)
		clf = LogisticRegression(penalty="l1", C=1, solver="liblinear")
		nn_scores, nn_f1_scores, tree_scores, tree_f1_scores, rank_per_case, tps, tns, fps, fns, p_scores, n_scores = acc_f1(nnclf, clf, 8, kf, data, labels)
			
		nn_result.append(np.mean(nn_scores))
		nn_f1_result.append(np.mean(nn_f1_scores))
		tree_result.append(np.mean(tree_scores))
		tree_f1_result.append(np.mean(tree_f1_scores))

		rank = np.add(rank,rank_per_case)
		
	# print("mean score ", np.mean(nn_scores), np.mean(tree_scores))
	rank_val_order = np.argsort(rank).flatten()
	top = []
	for i in range(nfeatures-1,nfeatures-4,-1):
		top.append(feature_names[rank_val_order[i]])
		print(feature_names[rank_val_order[i]],)
		
	plt.figure()
	plt.plot(list(map(math.log, hidden_units)), nn_result, color="r", linestyle="-", linewidth=1)
	plt.plot(list(map(math.log, hidden_units)), tree_result, color="g", linestyle="-", linewidth=1)
	plt.xlabel("log(hidden_units)")
	plt.ylabel("accuracy")
	plt.title("lasso + ann with different number of hidden units (red for nn, green for lassoann)" + "\n" + "top three features: " + top[0] + ", " + top[1] + ", " + top[2])
	plt.savefig("LASSO_ann_hidden_units_accuarcy.png")
		
	plt.figure()
	plt.plot(list(map(math.log, hidden_units)), nn_f1_result, color="r", linestyle="-", linewidth=1)
	plt.plot(list(map(math.log, hidden_units)), tree_f1_result, color="g", linestyle="-", linewidth=1)
	plt.xlabel("log(hidden_units)")
	plt.ylabel("f1_score")
	plt.title("lasso + ann with different number of hidden units (red for nn, green for lassoann)" + "\n" + "top three features: " + top[0] + ", " + top[1] + ", " + top[2])
	plt.savefig("LASSO_ann_hidden_units_f1_score.png")
	#plt.show()
		
	"activation functions"
	rank = np.zeros((nfeatures))
	nn_result = []
	nn_f1_result = []
	tree_result = []
	tree_f1_result = []		
	for activation in activations:
		nnclf = MLPClassifier(hidden_layer_sizes=(2,), activation=activation, solver='lbfgs', max_iter=1000, tol=0.0001, warm_start=False)
		clf = LogisticRegression(penalty="l1", C=1, solver="liblinear")
		nn_scores, nn_f1_scores, tree_scores, tree_f1_scores, rank_per_case, tps, tns, fps, fns, p_scores, n_scores = acc_f1(nnclf, clf, 8, kf, data, labels)
			
		nn_result.append(np.mean(nn_scores))
		nn_f1_result.append(np.mean(nn_f1_scores))
		tree_result.append(np.mean(tree_scores))
		tree_f1_result.append(np.mean(tree_f1_scores))

		rank = np.add(rank,rank_per_case)
		
	# print("mean score ", np.mean(nn_scores), np.mean(tree_scores))
	rank_val_order = np.argsort(rank).flatten()
	top = []
	for i in range(nfeatures-1,nfeatures-4,-1):
		top.append(feature_names[rank_val_order[i]])
		print(feature_names[rank_val_order[i]],)
		
	plt.figure()
	plt.plot(activations, nn_result, color="r", linestyle="-", linewidth=1)
	plt.plot(activations, tree_result, color="g", linestyle="-", linewidth=1)
	plt.xlabel("activation function")
	plt.ylabel("accuracy")
	plt.title("lasso + ann with different activation function (red for nn, green for lassoann)" + "\n" + "top three features: " + top[0] + ", " + top[1] + ", " + top[2])
	plt.savefig("LASSO_ann_act_func_accuarcy.png")
		
	plt.figure()
	plt.plot(activations, nn_f1_result, color="r", linestyle="-", linewidth=1)
	plt.plot(activations, tree_f1_result, color="g", linestyle="-", linewidth=1)
	plt.xlabel("activation function")
	plt.ylabel("f1_score")
	plt.title("lasso + ann with different activation function (red for nn, green for lassoann)" + "\n" + "top three features: " + top[0] + ", " + top[1] + ", " + top[2])
	plt.savefig("LASSO_ann_act_func_f1_score.png")
	#plt.show()
		
	"alpha"
	rank = np.zeros((nfeatures))
	nn_result = []
	nn_f1_result = []
	tree_result = []
	tree_f1_result = []		
	for alpha in alphas:
		nnclf = MLPClassifier(hidden_layer_sizes=(2,), activation='relu', solver='lbfgs', alpha=alpha, max_iter=1000, tol=0.0001, warm_start=False)
		clf = LogisticRegression(penalty="l1", C=1, solver="liblinear")
		nn_scores, nn_f1_scores, tree_scores, tree_f1_scores, rank_per_case, tps, tns, fps, fns, p_scores, n_scores = acc_f1(nnclf, clf, 8, kf, data, labels)
			
		nn_result.append(np.mean(nn_scores))
		nn_f1_result.append(np.mean(nn_f1_scores))
		tree_result.append(np.mean(tree_scores))
		tree_f1_result.append(np.mean(tree_f1_scores))

		rank = np.add(rank,rank_per_case)
		
	# print("mean score ", np.mean(nn_scores), np.mean(tree_scores))
	rank_val_order = np.argsort(rank).flatten()
	top = []
	for i in range(nfeatures-1,nfeatures-4,-1):
		top.append(feature_names[rank_val_order[i]])
		print(feature_names[rank_val_order[i]],)
		
	plt.figure()
	plt.plot(list(map(math.log, alphas)), nn_result, color="r", linestyle="-", linewidth=1)
	plt.plot(list(map(math.log, alphas)), tree_result, color="g", linestyle="-", linewidth=1)
	plt.xlabel("log(alphas)")
	plt.ylabel("accuracy")
	plt.title("lasso + ann with different l2 penalty (red for nn, green for lassoann)" + "\n" + "top three features: " + top[0] + ", " + top[1] + ", " + top[2])
	plt.savefig("LASSO_ann_alpha_accuarcy.png")
		
	plt.figure()
	plt.plot(list(map(math.log, alphas)), nn_f1_result, color="r", linestyle="-", linewidth=1)
	plt.plot(list(map(math.log, alphas)), tree_f1_result, color="g", linestyle="-", linewidth=1)
	plt.xlabel("log(alphas)")
	plt.ylabel("f1_score")
	plt.title("lasso + ann with different l2 penalty (red for nn, green for lassoann)" + "\n" + "top three features: " + top[0] + ", " + top[1] + ", " + top[2])
	plt.savefig("LASSO_ann_alpha_f1_score.png")
	"""
	#plt.show()

