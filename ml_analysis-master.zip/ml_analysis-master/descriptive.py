import csv
import math
import numpy as np

from sklearn import tree
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import KFold,StratifiedKFold
from imblearn.over_sampling import RandomOverSampler
from sklearn.preprocessing import scale, MinMaxScaler
from sklearn.linear_model import Lasso, SGDClassifier, LogisticRegression, ElasticNet, RidgeClassifier

from sklearn.svm import SVC, SVR, LinearSVC
from sklearn.tree import DecisionTreeClassifier, ExtraTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, BaggingClassifier, IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.covariance import EllipticEnvelope

from sklearn.metrics import f1_score
import matplotlib.pyplot as plt

def isfloat(value):
	try:
		float(value)
		return True
	except ValueError:
		return False

def data_clean(data, labels):
	clf = SVC(C=12, kernel="rbf", gamma='scale')
	clf = clf.fit(data, labels)
	pred = clf.predict(data)
	idx=[]
	for i in range(len(data)):
		if pred[i]==labels[i]:
			idx.append(i)
	return data[idx], labels[idx]

if __name__ == "__main__":
	#nfold = 8
	nfeatures = 11
	feature_names = ["Info", "Procedure", "uniqueparticipants", "AdminSize", "polarization_total", "brownfield","project_size_person", "gini_freq", "project_age", "ifstart","ratio"]
	# methods = ["Lasso", "RandomForest", "ElasticNet", "RidgeClassifier"]
	
	with open('data_new.csv','r') as f:
		# read in data
		reader = csv.reader(f)
		next(reader)
		data = []
		labels = []

		for row in reader:
			d = []
			# d = [float(row[i]) for i in range(1,1+nfeatures)]
			nfeatures = len(row)-2
			for i in range (1, 1+nfeatures):
				if isfloat(row[i]):
					d.append(float(row[i]))
				else:
					d.append(float(0))
			data.append(d)

			if row[len(row)-1] == "1":
				labels.append(1)
			else:
				labels.append(0)
		data = np.array(data)
		
		"""
		x = np.array([i for i in range(data.shape[0])])
		for i in range(nfeatures):
			plt.figure()
			y = data[:, i]
			print(np.mean(y))
			#plt.plot(x, y[np.argsort(y)], color="r", linestyle="-", linewidth=1)
			plt.hist(y, bins=31)
			plt.title("Distribution of feature %s before scale and data cleaning \n Mean: %f Median: %f" % (feature_names[i], np.mean(y), np.median(y)))
			#plt.savefig("%s_before_preprocessing.png" % (feature_names[i]))
			plt.savefig("%s_before_preprocessing_hist.png" % (feature_names[i]))
		plt.show()
		"""

		data = scale(data)
		# data = MinMaxScaler().fit_transform(data)
		labels = np.array(labels)
		data, labels = data_clean(data, labels)
		npos = np.count_nonzero(labels)
		nneg = len(labels)-npos
		print("pos", npos, "neg", nneg)
		
		"""
		x = np.array([i for i in range(npos+nneg)])
		for i in range(nfeatures):
			plt.figure()
			y = data[:, i]
			print(np.mean(y))
			#plt.plot(x, y[np.argsort(y)], color="r", linestyle="-", linewidth=1)
			plt.hist(y, bins=31)
			plt.title("Distribution of feature %s after scale and data cleaning \n Median: %f" % (feature_names[i], np.median(y)))
			#plt.savefig("%s_after_preprocessing.png" % (feature_names[i]))
			plt.savefig("%s_after_preprocessing_hist.png" % (feature_names[i]))
		plt.show()
		"""
		
		"cross_correlation"
		p_idx = labels==1
		n_idx = labels==0
		#print(np.count_nonzero(p_idx==True) + np.count_nonzero(n_idx==True))
		
		for i in range(1):
			for j in range(nfeatures):
				x = data[:, 2]
				y = data[:, j]
				plt.figure()
				#plt.xcorr(x, y, usevlines=True, normed=True, lw=2)
				plt.scatter(x[p_idx], y[p_idx], c="r")
				plt.scatter(x[n_idx], y[n_idx], c="g")
				#plt.grid(True)
				plt.title("cross_correlation between %s and %s" % (feature_names[2], feature_names[j]))
				#plt.savefig("cross_correlation_%s_%s.png" % (feature_names[i], feature_names[j]))	
		plt.show()
		
