import csv 

def read_data(filename):
	with open(filename,'r') as f:
		reader = csv.reader(f)
		next(reader)
		data = []
		labels = []
		for row in reader:
			d = []
			# d = [float(row[i]) for i in range(1,1+nfeatures)]
			nfeatures = len(row)-2
			for i in range (1, 1+nfeatures):
				if isfloat(row[i]):
					d.append(float(row[i]))
				else:
					d.append(float(0))
			data.append(d)

			if row[len(row)-1] == "1":
				labels.append(1)
			else:
				labels.append(0)

		return np.array(data), np.array(labels)
