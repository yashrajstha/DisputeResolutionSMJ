import csv
import numpy as np
import pandas as pd

def xlsx_to_csv(filename, filesave):
	lsx_file = pd.read_excel(filename, index_col=0)
	csv_file = lsx_file.to_csv(filesave, encoding='utf-8')

def del_empty_row(filename, filesave):
	f = open(filename, "r")
	reader = csv.reader(f)
	out_f = open(filesave, "w")
	writer = csv.writer(out_f)
	for row in reader:
		if any(row):
			writer.writerow(row)
	f.close()
	out_f.close()

def read_data(filename, issue):
	with open(filename, "r") as f:
		reader = csv.reader(f)
		next(reader)
		
		
		for row in reader:
			
			
			if row[0] in issue:
				for i in range(1,len(issue[row[0]])):
					if issue[row[0]][i] == '':
						issue[row[0]][i] = row[i]
			else:
				issue[row[0]] = row
		return issue


if __name__ == "__main__":
	
	#xlsx_to_csv("merged.xls", "merged.csv")
	#xlsx_to_csv("merged_Batches 4&5.xls", "merged_batches_4_5.csv")
	
	filenames = ["merged.csv", "merged_batches_4_5.csv"]
	with open(filenames[0], "r") as f:
		reader = csv.reader(f)
		#issue_name = [row[0] for row in reader]
		for i, row in enumerate(reader):
			if i==0:
				columns = row
		print(columns)

	issue = {}
	for filename in filenames:
		issue = read_data(filename, issue)
	
	print(len(issue.keys()))
	
	data = pd.DataFrame.from_dict(issue, orient='index', columns=columns)
	data.to_csv('merge_final.csv', columns=columns, index=False, header=True)
	
			
