# Bagging of Lasso

import csv
import math
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import scale, MinMaxScaler
from sklearn.linear_model import SGDClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC

from sklearn.metrics import f1_score, matthews_corrcoef
import matplotlib.pyplot as plt

from imblearn.over_sampling import SMOTE

def read_data(filename):
	with open(filename,'r') as f:
		reader = csv.reader(f)
		next(reader)
		data = []
		labels = []
		for row in reader:
			d = []
			# d = [float(row[i]) for i in range(1,1+nfeatures)]
			nfeatures = len(row)-2
			for i in range (1, 1+nfeatures):
				if isfloat(row[i]):
					d.append(float(row[i]))
				else:
					d.append(float(0))
			data.append(d)

			if row[len(row)-1] == "1":
				labels.append(1)
			else:
				labels.append(0)

		return np.array(data), np.array(labels)

def stratified_bootstrap(pos_idx,neg_idx):
	npos = len(pos_idx)
	nneg = len(neg_idx)

	# sample from pos
	boot_pos = np.random.choice(pos_idx,npos)
	# sample from neg
	boot_neg = np.random.choice(neg_idx,nneg)

	return np.append(boot_pos,boot_neg)

def vote(predictions,nnsize):
	votes = np.sum(predictions,axis=0)
	for i in range(len(votes)):
		if votes[i]>= (nnsize+1)/2:
			votes[i] = 1
		else:
			votes[i] = 0
	return votes

def error_rate(votes,labels):
	hit = 0
	for i in range(len(votes)):
		if votes[i] == labels[i]:
			hit = hit+1
	return 1.0*hit/len(votes)

def isfloat(value):
	try:
		float(value)
		return True
	except ValueError:
		return False

def confusion(pred,labels):
	TP = 0
	TN = 0
	FP = 0
	FN = 0
	total = len(labels)
	for i in range(total):
		if pred[i] == labels[i]:
			if pred[i]==1:
				TP += 1
			else:
				TN += 1
		else:
			if pred[i]==1:
				FP += 1
			else:
				FN += 1
	return TP, TN, FP, FN

def data_clean(data, labels):
	clf = SVC(C=13, kernel="rbf", gamma='scale')
	clf = clf.fit(data, labels)
	pred = clf.predict(data)
	idx=[]
	for i in range(len(data)):
		if pred[i]==labels[i]:
			idx.append(i)
	return data[idx], labels[idx]
  
def extract_data_new_labels(datafile, labelfile):
	label_file = open(labelfile,'r')
	label_reader = csv.reader(label_file)
	next(label_reader)
	label_dict = {}
	for row in label_reader:
		label_dict[row[0]] = int(row[-1])
	label_file.close()
	
	with open(datafile,'r') as f:
		reader = csv.reader(f)
		next(reader)
		data = []
		labels = []
		for row in reader:
			d = []
			# d = [float(row[i]) for i in range(1,1+nfeatures)]
			nfeatures = len(row)-2
			for i in range (1, 1+nfeatures):
				if isfloat(row[i]):
					d.append(float(row[i]))
				else:
					d.append(float(0))
			data.append(d)
			labels.append(label_dict[row[0]])
			
		return np.array(data), np.array(labels)

def data_transform_mul_brownfield(data, nfeatures, feature_names):
	idx_p_brownfeild = data[:, 5]==1
	idx_n_brownfeild = data[:, 5]==0	
	print(np.count_nonzero(idx_p_brownfeild==True), np.count_nonzero(idx_n_brownfeild==True))
	musk = np.array(feature_names)!="brownfield"
	print(musk)
	data = data[:, musk]	
	data = np.concatenate((data, data), axis=1)
	data[idx_n_brownfeild, (nfeatures - 1):] = 0
	
	nfeatures = (nfeatures - 1) * 2
	feature_names = np.array(feature_names)[musk]
	feature_names = np.append(feature_names, feature_names)
	
	return data, nfeatures, feature_names

def data_transform_brownfield(data, labels, nfeatures, feature_names, brownfield):
	idx_p_brownfeild = data[:, 5]==1
	idx_n_brownfeild = data[:, 5]==0	
	print(np.count_nonzero(idx_p_brownfeild==True), np.count_nonzero(idx_n_brownfeild==True))
	musk = np.array(feature_names)!="brownfield"
	print(musk)
	
	if brownfield == 0:
		data = data[np.ix_(idx_n_brownfeild, musk)]
		labels = labels[idx_n_brownfeild]
	else:
		data = data[np.ix_(idx_p_brownfeild, musk)]
		labels = labels[idx_p_brownfeild]
	
	feature_names = np.array(feature_names)[musk]
	nfeatures = nfeatures - 1
	
	return data, labels, nfeatures, feature_names

if __name__ == "__main__":
	#nbag = 41
	nfold = 8
	nfeatures = 11
	feature_names = ["Info", "Procedure", "uniqueparticipants", "AdminSize", "polarization_total", "brownfield","project_size_person", "gini_freq", "project_age", "ifstart","ratio"]
	data, labels = read_data('data_new_183.csv')
	#data, labels = extract_data_new_labels('data_new_183.csv', 'merge_final.csv')
	#data, nfeatures, feature_names = data_transform_mul_brownfield(data, nfeatures, feature_names)
	#data, labels, nfeatures, feature_names = data_transform_brownfield(data, labels, nfeatures, feature_names, 0)
	#data, labels, nfeatures, feature_names = data_transform_brownfield(data, labels, nfeatures, feature_names, 1)

	data = scale(data)
	#data, labels = data_clean(data, labels)
	npos = np.count_nonzero(labels)
	nneg = len(labels)-npos
	print("pos", npos, "neg", nneg)

	# cross-validation
	kf = StratifiedKFold(n_splits=nfold, shuffle=True)

	SM = SMOTE(random_state=42)
	data, labels = SM.fit_resample(data, labels)
	print(data.shape)
		
	result = []
	f1_result = []
	mcc_result = []

		
	#n_bags = [1, 2, 5, 10, 20, 50, 100, 150]
	n_bags = [50]
	#n_bags = [50 for i in range(50)]
		
	tps = []
	tns = []
	fps = []
	fns = []
	p_scores = []
	n_scores = []	
	rank = np.zeros((nfeatures))
			
	#data = data[np.ix_(idx_n_brownfeild, musk)]
	#labels = labels[idx_n_brownfeild]
	#feature_names = np.array(feature_names)[musk]
	#nfeatures = nfeatures-1
	#rank = np.zeros((nfeatures))
		
	#data = data[idx_n_brownfeild]
	#labels = labels[idx_n_brownfeild]
		
	for nbag in n_bags:
		lasso_scores = []
		f1_scores = []
		mcc_scores = []
		
		rank_per_case = np.zeros((nfeatures))
		tps = []
		tns = []
		fps = []
		fns = []
		p_scores = []
		n_scores = []
		for train_idx, test_idx in kf.split(data,labels):
			train_data = data[train_idx]
			test_data = data[test_idx]
			train_labels = labels[train_idx]
			test_labels = labels[test_idx]
	
			# get class indices
			pos_idx = []
			neg_idx = []
			for i in range(len(train_labels)):
				if train_labels[i] == 1:
					pos_idx.append(i)
				else:
					neg_idx.append(i)
	
			# bagging
			predictions = []
			rank_per_fold = np.zeros((nfeatures))
			for i in range(nbag):
				# bootstrapping
				boot_idx = stratified_bootstrap(pos_idx,neg_idx)
				boot_train_data = train_data[boot_idx]
				boot_train_labels = train_labels[boot_idx]
				
				clf = LogisticRegression(penalty="l1", C=5, solver="liblinear")					
				clf = clf.fit(boot_train_data,boot_train_labels)
					
				pred_per_boot = clf.predict(test_data)
				predictions.append(pred_per_boot)
					
				coef_per_boot = clf.coef_
				coef_rank_per_boot = np.argsort(np.abs(coef_per_boot)).flatten()
				rank_per_boot = np.zeros(nfeatures)
				for i in range(nfeatures):
					rank_per_boot[coef_rank_per_boot[i]] = i
				rank_per_fold = np.add(rank_per_fold,rank_per_boot)

			rank_per_case = np.add(rank_per_case, rank_per_fold)
				
			predictions = vote(predictions,nbag)
				
			lasso_score = error_rate(predictions,test_labels)
			lasso_scores.append(lasso_score)
				
			f1 = f1_score(test_labels, predictions)
			f1_scores.append(f1)
			mcc = matthews_corrcoef(test_labels, predictions)
			mcc_scores.append(mcc)
				
			tp, tn, fp, fn = confusion(predictions,test_labels)
			tps.append(tp)
			tns.append(tn)
			fps.append(fp)
			fns.append(fn)
			p_scores.append(1.0*tp/(tp+fn))
			n_scores.append(1.0*tn/(tn+fp))

		rank = np.add(rank,rank_per_case)

		result.append(np.mean(lasso_scores))
		f1_result.append(np.mean(f1_scores))
		mcc_result.append(np.mean(mcc_scores))
			
	rank_val_order = np.argsort(rank).flatten()
		
	print(rank/(nfold*50.0))
	print(np.mean(result), np.mean(f1_result), np.mean(mcc_result))
	print("tp", np.sum(tps),"tn",np.sum(tns),"fp",np.sum(fps),"fn",np.sum(fns))
	print(np.mean(p_scores), np.mean(n_scores))
	
	top = []
	for i in range(nfeatures-1,nfeatures-4,-1):
		top.append(feature_names[rank_val_order[i]])
		print(feature_names[rank_val_order[i]],)


